//Program Header Here

#include <iostream>
#include "BinaryTree.h"
#include "AVLTree.h"
#include "timer.h"

using namespace std;

int main(){
    srand(time(0));
    
    BinaryTree<int> BTree;
    AVLTree<int> ATree;
    
    int numNodes, upperBound;
    double start, finish;
    
    cout << "How many nodes would you like in the tree?" << endl;
    cin >> numNodes;
    
    cout << "What would you like the upper bound of the integer values to be (lower bound is zero)?" << endl;
    cin >> upperBound;
    
    GET_TIME(start);
    for (int i = 0; i < numNodes; i++){
        ATree.insertNode(rand() % upperBound + 1);
    }
    GET_TIME(finish);
    
    cout << "Time for AVLTree: " << finish - start << endl; 
    
    GET_TIME(start);
    for (int i = 0; i < numNodes; i++){
        BTree.insertNode(rand() % upperBound + 1);
    }
    BTree.balance();
    GET_TIME(finish);
    
     cout << "Time for BinaryTree: " << finish - start << endl; 
    
}
